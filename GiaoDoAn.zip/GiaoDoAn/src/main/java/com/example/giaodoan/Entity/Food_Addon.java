package com.example.giaodoan.Entity;

import javax.persistence.*;

@Entity(name = "food_addon")
public class Food_Addon {
    // có khóa ngoại => n - 1
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    //
    @Column(name = "id_food")
    private int id_food;
    @ManyToOne
    @JoinColumn(name = "id_food")
    private Food food;
    //

    @Column(name = "name")
    private String name;

    @Column(name = "image")
    private String image;

    @Column(name = "price")
    private int price;



}
