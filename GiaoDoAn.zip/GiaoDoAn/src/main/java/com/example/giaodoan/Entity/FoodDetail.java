package com.example.giaodoan.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Set;

@Entity(name = "food_detail")
public class FoodDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_food")
    private int id_food;

    // FoodDetail - Food ( 1 - 1 )
    @JsonIgnore
    @OneToOne
    @JoinColumn(name = "id_food")
    private Food food;
    //

    //
    @OneToMany(mappedBy = "foodDetail")
    private Set<Food_Material> foodMaterials;
    //

    @Column(name = "description")
    private String description;

    @Column(name = "create_date")
    private String create_date;

    @Column(name = "rating")
    private float rating;

    public int getId_food() {
        return id_food;
    }

    public void setId_food(int id_food) {
        this.id_food = id_food;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCreate_date() {
        return create_date;
    }

    public void setCreate_date(String create_date) {
        this.create_date = create_date;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }
}
