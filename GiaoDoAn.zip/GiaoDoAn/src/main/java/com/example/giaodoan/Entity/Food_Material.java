package com.example.giaodoan.Entity;

import javax.persistence.*;

@Entity(name = "food_material")
public class Food_Material {

    @Id
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_food")
    private FoodDetail foodDetail;

    @Id
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_material")
    private Material material;
}
