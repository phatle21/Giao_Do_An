package com.example.giaodoan.Entity;

import javax.persistence.*;

@Entity(name = "t_order")
public class T_Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    //
    @ManyToOne
    @JoinColumn(name = "id_user")
    private User user;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
    //

    @Column
    private String estimate_ship;

    @Column
    private String deliver_address;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEstimate_ship() {
        return estimate_ship;
    }

    public void setEstimate_ship(String estimate_ship) {
        this.estimate_ship = estimate_ship;
    }

    public String getDeliver_address() {
        return deliver_address;
    }

    public void setDeliver_address(String deliver_address) {
        this.deliver_address = deliver_address;
    }
}
