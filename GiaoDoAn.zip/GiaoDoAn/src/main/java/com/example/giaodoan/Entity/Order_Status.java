package com.example.giaodoan.Entity;

import javax.persistence.*;

@Entity(name = "order_status")
public class Order_Status {
    @Id
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_order")
    private Food_Order foodOrder;

    //
    @Id
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_status")
    private Status status;

}
