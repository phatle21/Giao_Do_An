package com.example.giaodoan.Entity;

import javax.persistence.*;
import java.util.Set;

@Entity(name = "food_order")
public class Food_Order {

    @Id
    private int id_order;
    //
    @OneToMany(mappedBy = "foodOrder")
    private Set<Order_Status> orderStatus;

    public Set<Order_Status> getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(Set<Order_Status> orderStatus) {
        this.orderStatus = orderStatus;
    }

    //
    @Column(name = "id_food")
    private int id_food;
    @ManyToOne
    @JoinColumn(name = "id_food")
    private Food food;
    //

    @Column(name = "price")
    private float price;

    @Column(name = "quality")
    private int quality;

    @Column(name = "id_promo")
    private int id_promo;

    public int getId_order() {
        return id_order;
    }

    public void setId_order(int id_order) {
        this.id_order = id_order;
    }

    public int getId_food() {
        return id_food;
    }

    public void setId_food(int id_food) {
        this.id_food = id_food;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public int getQuality() {
        return quality;
    }

    public void setQuality(int quality) {
        this.quality = quality;
    }

    public int getId_promo() {
        return id_promo;
    }

    public void setId_promo(int id_promo) {
        this.id_promo = id_promo;
    }
}
