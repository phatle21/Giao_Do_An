package com.example.giaodoan.Entity;

import javax.persistence.*;

@Entity(name = "restaurant_review")
public class Restaurent_Review {
    // bảng nào giữ khóa ngoại thì JoinColumn => n - 1
    // bảng còn lại có thể sẽ => 1 - n

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    //
    @Column(name = "id_restaurant")
    private int id_restaurant;
    @ManyToOne
    @JoinColumn(name = "id_restaurant")
    private Restaurant restaurant;
    //

    @Column(name = "content")
    private String content;

    @Column(name = "rate")
    private float rate;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_restaurant() {
        return id_restaurant;
    }

    public void setId_restaurant(int id_restaurant) {
        this.id_restaurant = id_restaurant;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public float getRate() {
        return rate;
    }

    public void setRate(float rate) {
        this.rate = rate;
    }
}
