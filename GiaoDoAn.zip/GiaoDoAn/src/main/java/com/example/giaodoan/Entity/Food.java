package com.example.giaodoan.Entity;

import javax.persistence.*;
import java.util.Set;

@Entity(name = "food")
public class Food {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    // Food - FoodDetail ( 1 - 1 )
    @OneToOne(mappedBy = "food")
    private FoodDetail foodDetail;

    public FoodDetail getFoodDetail() {
        return foodDetail;
    }

    public void setFoodDetail(FoodDetail foodDetail) {
        this.foodDetail = foodDetail;
    }

    // Food ( 1 - n ) - Food_Addon ( n - 1 )
    @OneToMany(mappedBy = "food")
    private Set<Food_Addon> foodAddons;

    public Set<Food_Addon> getFoodAddons() {
        return foodAddons;
    }

    public void setFoodAddons(Set<Food_Addon> foodAddons) {
        this.foodAddons = foodAddons;
    }

    //
    @OneToMany(mappedBy = "food")
    private Set<FoodReview> foodReviews;

    public Set<FoodReview> getFoodReviews() {
        return foodReviews;
    }

    public void setFoodReviews(Set<FoodReview> foodReviews) {
        this.foodReviews = foodReviews;
    }

    //
    @OneToMany(mappedBy = "food")
    private Set<Food_Order> foodOrders;

    public Set<Food_Order> getFoodOrders() {
        return foodOrders;
    }

    public void setFoodOrders(Set<Food_Order> foodOrders) {
        this.foodOrders = foodOrders;
    }

    //
    @Column(name = "id_category") // khóa ngoại
    private int idCategory;
    @ManyToOne
    @JoinColumn(name = "id_category")
    private Category category;
    //

    @Column(name = "id_restaurant") // khóa ngoại
    private int idRestaurant;
    @ManyToOne
    @JoinColumn(name = "id_restaurant")
    private Restaurant restaurant;
    //

    @Column(name = "name")
    private String name;

    @Column(name = "image")
    private String image;

    @Column(name = "price")
    private int price;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getIdCategory() {
        return idCategory;
    }

    public void setIdCategory(int idCategory) {
        this.idCategory = idCategory;
    }

    public int getIdRestaurant() {
        return idRestaurant;
    }

    public void setIdRestaurant(int idRestaurant) {
        this.idRestaurant = idRestaurant;
    }
}
